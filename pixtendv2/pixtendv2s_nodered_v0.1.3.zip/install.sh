#!/bin/bash
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

# MIT License
# 
# Copyright (C) 2021 Kontron Electronics GmbH <support@pixtend.de>
# 
# Permission is hereby granted, free of charge, to any person obtaining
# a copy of this software and associated documentation files
# (the "Software"), to deal in the Software without restriction,
# including without limitation the rights to use, copy, modify, merge,
# publish, distribute, sublicense, and/or sell copies of the Software,
# and to permit persons to whom the Software is furnished to do so,
# subject to the following conditions:
# 
# The above copyright notice and this permission notice shall be included
# in all copies or substantial portions of the Software.
# 
# THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
# OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
# THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
# LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
# FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
# DEALINGS IN THE SOFTWARE.
# 

sudo apt-get update
sudo apt-get -y install unzip

tar xvfz sysv_ipc-0.7.0.tar.gz
cd ./sysv_ipc-0.7.0/
sudo python setup.py install
cd ..
mkdir ~/nodered-px2
mkdir ~/nodered-px2/pixtend2s
mkdir ~/nodered-px2/pixtend2l
mkdir ~/nodered-px2/srv
unzip -o srv.zip -d ~/nodered-px2/srv
unzip -o npxv2sio.zip -d ~/nodered-px2/pixtend2s
unzip -o npxv2lio.zip -d ~/nodered-px2/pixtend2l
cd ~/nodered-px2/srv
chmod +x makepixtendsrv2
./makepixtendsrv2 go
cd ..
cd ./pixtend2s
chmod +777 npxv2sio
cd ..
cd ./pixtend2l
chmod +777 npxv2lio
cd $DIR
sudo rm -r -f sysv_ipc-0.7.0
cd ~/nodered-px2/pixtend2s
sudo npm link
cd ~/.node-red
npm link node-red-contrib-pixtendv2s
cd ~/nodered-px2/pixtend2l
sudo npm link
cd ~/.node-red
npm link node-red-contrib-pixtendv2l
cd ..



